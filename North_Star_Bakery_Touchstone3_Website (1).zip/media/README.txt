Extract the official North Star Bakery media ZIP into this media folder. Keep original filenames.
