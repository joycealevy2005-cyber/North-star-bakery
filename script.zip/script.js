"use strict";
// Product data and validation messages are separate, easy-to-update objects.
const bakeryProducts = [
  { id: "signature-loaf", name: "Signature Loaf", category: "Bread" },
  { id: "artisan-bread", name: "Artisan Bread", category: "Bread" },
  { id: "butter-pastry", name: "Butter Pastry", category: "Pastry" },
  { id: "celebration-cake", name: "Celebration Cake", category: "Cake" }
];
const validationMessages = {
  name: "Please enter your full name (at least 2 characters).",
  email: "Please enter a valid email address.",
  type: "Please select a request type.",
  pickup: "Please choose a pickup date for a pre-order.",
  past: "Please choose today or a future pickup date.",
  details: "Please describe your request in at least 10 characters."
};
const FAVORITES_KEY = "northStarBakeryFavorites";

function loadFavorites() {
  try {
    const value = JSON.parse(localStorage.getItem(FAVORITES_KEY) || "[]");
    return Array.isArray(value) ? value.filter(id => bakeryProducts.some(p => p.id === id)) : [];
  } catch (error) { return []; }
}
function saveFavorites(ids) {
  try { localStorage.setItem(FAVORITES_KEY, JSON.stringify(ids)); }
  catch (error) { document.getElementById("favorites-summary").textContent = "Your choices are shown here, but this browser cannot save them."; }
}
function updateFavoritesSummary(ids) {
  const summary = document.getElementById("favorites-summary");
  if (!summary) return;
  const names = bakeryProducts.filter(p => ids.includes(p.id)).map(p => p.name);
  summary.textContent = names.length ? `Saved favorites (${names.length}): ${names.join(", ")}.` : "No favorites selected yet.";
}
function renderFavorites() {
  const container = document.getElementById("favorite-options");
  if (!container) return;
  const selected = loadFavorites();
  bakeryProducts.forEach(product => {
    const label = document.createElement("label");
    label.className = "favorite-option";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = product.id;
    checkbox.checked = selected.includes(product.id);
    checkbox.addEventListener("change", () => {
      const current = loadFavorites();
      const next = checkbox.checked ? [...new Set([...current, product.id])] : current.filter(id => id !== product.id);
      saveFavorites(next);
      updateFavoritesSummary(next);
    });
    const name = document.createElement("span");
    name.textContent = `${product.name} (${product.category})`;
    label.append(checkbox, name);
    container.appendChild(label);
  });
  updateFavoritesSummary(selected);
  document.getElementById("clear-favorites").addEventListener("click", () => {
    saveFavorites([]);
    container.querySelectorAll("input[type=checkbox]").forEach(box => { box.checked = false; });
    updateFavoritesSummary([]);
  });
}
function showFieldError(field, message) {
  let error = document.getElementById(`${field.id}-error`);
  if (!error) {
    error = document.createElement("span");
    error.id = `${field.id}-error`;
    error.className = "field-error";
    field.insertAdjacentElement("afterend", error);
  }
  error.textContent = message;
  field.setAttribute("aria-invalid", message ? "true" : "false");
  if (message) field.setAttribute("aria-describedby", error.id);
  else field.removeAttribute("aria-describedby");
}
function validateField(field, form) {
  const value = field.value.trim();
  let message = "";
  switch (field.id) {
    case "full-name": if (value.length < 2) message = validationMessages.name; break;
    case "email": if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) message = validationMessages.email; break;
    case "request-type": if (!value) message = validationMessages.type; break;
    case "pickup-date":
      if (form.elements.request_type.value === "preorder") {
        if (!value) message = validationMessages.pickup;
        else {
          const today = new Date();
          const localToday = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
          if (value < localToday) message = validationMessages.past;
        }
      }
      break;
    case "item-details": if (value.length < 10) message = validationMessages.details; break;
  }
  showFieldError(field, message);
  return !message;
}
function setupFormValidation() {
  const form = document.getElementById("inquiry-form");
  if (!form) return;
  const fields = ["full-name", "email", "request-type", "pickup-date", "item-details"].map(id => document.getElementById(id));
  fields.forEach(field => {
    field.addEventListener("input", () => { if (field.getAttribute("aria-invalid") === "true") validateField(field, form); });
    field.addEventListener("change", () => {
      validateField(field, form);
      if (field.id === "request-type") validateField(document.getElementById("pickup-date"), form);
    });
  });
  form.addEventListener("submit", event => {
    event.preventDefault(); // This is a demonstration: never claim to send an order.
    const results = fields.map(field => validateField(field, form));
    const status = document.getElementById("form-status");
    if (results.every(Boolean)) {
      status.textContent = "Your details look good. This is a demonstration; no request has been sent. Please contact the bakery to confirm your order.";
      status.className = "form-success";
    } else {
      status.textContent = "Please correct the highlighted fields and try again.";
      status.className = "field-error";
      fields[results.indexOf(false)].focus();
    }
  });
}
document.addEventListener("DOMContentLoaded", () => { renderFavorites(); setupFormValidation(); });
